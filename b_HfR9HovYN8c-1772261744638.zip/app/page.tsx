import MigrationTracker from '@/components/migration-tracker/MigrationTracker';

export const metadata = {
  title: 'Migration Tracker | Governance Dashboard',
  description: 'Monitor and manage database migrations with governance controls',
};

export default function Home() {
  return (
    <main className="min-h-screen bg-background dark">
      <MigrationTracker />
    </main>
  );
}
