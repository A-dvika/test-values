'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Download, X } from 'lucide-react';

interface ExportDialogProps {
  onExport: (type: 'all' | 'selected' | 'failed') => void;
  onClose: () => void;
  hasSelected: boolean;
}

export function ExportDialog({
  onExport,
  onClose,
  hasSelected,
}: ExportDialogProps) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-card border border-border rounded-lg p-6 max-w-sm w-full mx-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
            <Download className="w-5 h-5" />
            Export Migrations
          </h2>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Description */}
        <p className="text-sm text-muted-foreground mb-6">
          Choose what data to export as CSV
        </p>

        {/* Export Options */}
        <div className="space-y-2">
          <Button
            variant="outline"
            onClick={() => onExport('all')}
            className="w-full justify-start h-auto py-3 text-foreground hover:bg-secondary"
          >
            <div className="text-left">
              <div className="font-semibold">Export All</div>
              <div className="text-xs text-muted-foreground">Download all migrations in current view</div>
            </div>
          </Button>

          {hasSelected && (
            <Button
              variant="outline"
              onClick={() => onExport('selected')}
              className="w-full justify-start h-auto py-3 text-foreground hover:bg-secondary"
            >
              <div className="text-left">
                <div className="font-semibold">Export Selected</div>
                <div className="text-xs text-muted-foreground">Download only selected migrations</div>
              </div>
            </Button>
          )}

          <Button
            variant="outline"
            onClick={() => onExport('failed')}
            className="w-full justify-start h-auto py-3 text-red-400 hover:bg-red-400/10"
          >
            <div className="text-left">
              <div className="font-semibold">Export Failed</div>
              <div className="text-xs text-muted-foreground">Download only failed migrations</div>
            </div>
          </Button>
        </div>

        {/* Close Button */}
        <Button
          variant="outline"
          onClick={onClose}
          className="w-full mt-4 border-border text-foreground hover:bg-secondary"
        >
          Close
        </Button>
      </div>
    </div>
  );
}
