'use client';

import React, { useState } from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { MoreVertical, CheckCircle2, RotateCcw, X, Clock } from 'lucide-react';
import type { Migration } from './MigrationTracker';

interface MigrationRowProps {
  migration: Migration;
  isSelected: boolean;
  onSelect: (selected: boolean) => void;
  onAction: (action: 'approve' | 'retry' | 'cancel' | 'reschedule', migrationIds: string[]) => void;
}

const getStatusColor = (status: Migration['status']) => {
  switch (status) {
    case 'Failed':
      return 'text-red-400 bg-red-400/10 border border-red-400/30';
    case 'Unapproved':
      return 'text-yellow-400 bg-yellow-400/10 border border-yellow-400/30';
    case 'In Progress':
      return 'text-blue-400 bg-blue-400/10 border border-blue-400/30';
    case 'Approved':
    case 'Queued':
      return 'text-blue-400 bg-blue-400/10 border border-blue-400/30';
    case 'Completed':
      return 'text-green-400 bg-green-400/10 border border-green-400/30';
    default:
      return 'text-gray-400 bg-gray-400/10 border border-gray-400/30';
  }
};

const getStatusIcon = (status: Migration['status']) => {
  switch (status) {
    case 'Failed':
      return '✕';
    case 'Unapproved':
      return '⏱';
    case 'In Progress':
      return '◐';
    case 'Completed':
      return '✓';
    case 'Approved':
      return '✓';
    default:
      return '○';
  }
};

export function MigrationRow({
  migration,
  isSelected,
  onSelect,
  onAction,
}: MigrationRowProps) {
  const [showActions, setShowActions] = useState(false);

  const canApprove = migration.status === 'Unapproved';
  const canRetry = migration.status === 'Failed';
  const canCancel = ['In Progress', 'Queued'].includes(migration.status);

  return (
    <div
      className="flex items-center gap-3 px-3 py-2 rounded-md bg-card border border-border hover:bg-secondary/50 transition-colors"
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      {/* Checkbox */}
      <Checkbox
        checked={isSelected}
        onCheckedChange={onSelect}
        className="border-border flex-shrink-0"
      />

      {/* Status Badge */}
      <div className={`px-2 py-1 rounded text-xs font-semibold flex items-center gap-1 flex-shrink-0 ${getStatusColor(migration.status)}`}>
        <span>{getStatusIcon(migration.status)}</span>
        <span>{migration.status}</span>
      </div>

      {/* Batch Name */}
      <div className="flex-1 min-w-0">
        <p className="text-sm text-foreground truncate">{migration.customBatchName}</p>
        <p className="text-xs text-muted-foreground truncate">
          {migration.submittedBy} • {migration.migrationType}
        </p>
      </div>

      {/* Migration Status */}
      <div className="hidden sm:block text-xs text-muted-foreground min-w-fit">
        {migration.migrationStatus}
      </div>

      {/* Quick Actions */}
      {showActions && (
        <div className="flex items-center gap-1 flex-shrink-0">
          {canApprove && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onAction('approve', [migration.id])}
              className="h-7 px-2 text-green-400 hover:bg-green-400/10"
              title="Approve"
            >
              <CheckCircle2 className="w-4 h-4" />
            </Button>
          )}
          {canRetry && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onAction('retry', [migration.id])}
              className="h-7 px-2 text-yellow-400 hover:bg-yellow-400/10"
              title="Retry"
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
          )}
          {canCancel && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onAction('cancel', [migration.id])}
              className="h-7 px-2 text-red-400 hover:bg-red-400/10"
              title="Cancel"
            >
              <X className="w-4 h-4" />
            </Button>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 px-2"
              >
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {canApprove && (
                <DropdownMenuItem onClick={() => onAction('approve', [migration.id])}>
                  Approve
                </DropdownMenuItem>
              )}
              {canRetry && (
                <DropdownMenuItem onClick={() => onAction('retry', [migration.id])}>
                  Retry
                </DropdownMenuItem>
              )}
              {canCancel && (
                <DropdownMenuItem onClick={() => onAction('cancel', [migration.id])}>
                  Cancel
                </DropdownMenuItem>
              )}
              <DropdownMenuItem onClick={() => onAction('reschedule', [migration.id])}>
                Reschedule
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )}
    </div>
  );
}
