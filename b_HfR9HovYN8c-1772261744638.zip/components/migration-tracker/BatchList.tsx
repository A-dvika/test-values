'use client';

import React from 'react';
import { ChevronDown, AlertCircle, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { MigrationRow } from './MigrationRow';
import type { Migration } from './MigrationTracker';

interface BatchListProps {
  batches: Array<{
    id: string;
    date: string;
    batchName: string;
    migrations: Migration[];
    stats: { total: number; failed: number; unapproved: number; inProgress: number };
    riskLevel: 'high' | 'medium' | 'low';
  }>;
  expandedBatches: Set<string>;
  selectedMigrations: Set<string>;
  onBatchToggle: (batchId: string) => void;
  onSelectMigration: (id: string, selected: boolean) => void;
  onAction: (action: 'approve' | 'retry' | 'cancel' | 'reschedule', migrationIds: string[]) => void;
}

const getRiskColor = (level: 'high' | 'medium' | 'low') => {
  switch (level) {
    case 'high':
      return 'border-l-4 border-l-red-400 bg-red-400/5';
    case 'medium':
      return 'border-l-4 border-l-yellow-400 bg-yellow-400/5';
    case 'low':
      return 'border-l-4 border-l-green-400 bg-green-400/5';
  }
};

export function BatchList({
  batches,
  expandedBatches,
  selectedMigrations,
  onBatchToggle,
  onSelectMigration,
  onAction,
}: BatchListProps) {
  if (batches.length === 0) {
    return (
      <Card className="p-8 text-center border-border bg-card">
        <p className="text-muted-foreground">No migrations match your filters</p>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {batches.map((batch) => {
        const isExpanded = expandedBatches.has(batch.id);
        const allBatchSelected = batch.migrations.every(m => selectedMigrations.has(m.id));
        const someBatchSelected = batch.migrations.some(m => selectedMigrations.has(m.id));

        return (
          <Card
            key={batch.id}
            className={`border border-border bg-card overflow-hidden transition-all ${getRiskColor(batch.riskLevel)}`}
          >
            {/* Batch Header */}
            <button
              onClick={() => onBatchToggle(batch.id)}
              className="w-full px-4 py-4 flex items-center gap-4 hover:bg-secondary/50 transition-colors text-left"
            >
              {/* Checkbox */}
              <Checkbox
                checked={allBatchSelected}
                indeterminate={someBatchSelected && !allBatchSelected}
                onCheckedChange={(checked) => {
                  batch.migrations.forEach(m => {
                    onSelectMigration(m.id, checked as boolean);
                  });
                }}
                onClick={(e) => e.stopPropagation()}
                className="border-border"
              />

              {/* Expand Arrow */}
              <ChevronDown
                className={`w-5 h-5 text-muted-foreground transition-transform flex-shrink-0 ${
                  isExpanded ? 'rotate-0' : '-rotate-90'
                }`}
              />

              {/* Batch Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-2">
                  <span className="font-semibold text-foreground">{batch.batchName}</span>
                  <span className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded">
                    {batch.date}
                  </span>
                </div>

                {/* Status Bar */}
                <div className="flex items-center gap-3">
                  <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden max-w-xs">
                    <div
                      className="h-full bg-gradient-to-r from-red-400 via-yellow-400 to-green-400"
                      style={{
                        width: `${((batch.stats.total - batch.stats.failed) / batch.stats.total) * 100}%`,
                      }}
                    />
                  </div>
                  <div className="flex items-center gap-4 text-xs">
                    {batch.stats.failed > 0 && (
                      <div className="flex items-center gap-1">
                        <XCircle className="w-4 h-4 text-red-400" />
                        <span className="text-red-400">{batch.stats.failed}</span>
                      </div>
                    )}
                    {batch.stats.unapproved > 0 && (
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4 text-yellow-400" />
                        <span className="text-yellow-400">{batch.stats.unapproved}</span>
                      </div>
                    )}
                    {batch.stats.inProgress > 0 && (
                      <div className="flex items-center gap-1">
                        <AlertCircle className="w-4 h-4 text-blue-400" />
                        <span className="text-blue-400">{batch.stats.inProgress}</span>
                      </div>
                    )}
                    <span className="text-muted-foreground">
                      {batch.stats.total} total
                    </span>
                  </div>
                </div>
              </div>
            </button>

            {/* Batch Details (Expanded) */}
            {isExpanded && (
              <div className="border-t border-border bg-secondary/30 p-4">
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {batch.migrations.map((migration) => (
                    <MigrationRow
                      key={migration.id}
                      migration={migration}
                      isSelected={selectedMigrations.has(migration.id)}
                      onSelect={(selected) => onSelectMigration(migration.id, selected)}
                      onAction={onAction}
                    />
                  ))}
                </div>
              </div>
            )}
          </Card>
        );
      })}
    </div>
  );
}
