'use client';

import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { ChevronDown, Search, Filter } from 'lucide-react';
import type { FilterState } from './MigrationTracker';

interface SidebarFiltersProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
}

const STATUS_OPTIONS = [
  { value: 'Queued', label: 'Queued', color: 'text-blue-400' },
  { value: 'Approved', label: 'Approved', color: 'text-green-400' },
  { value: 'In Progress', label: 'In Progress', color: 'text-blue-400' },
  { value: 'Completed', label: 'Completed', color: 'text-green-400' },
  { value: 'Failed', label: 'Failed', color: 'text-red-400' },
  { value: 'Unapproved', label: 'Awaiting Approval', color: 'text-yellow-400' },
];

const TYPE_OPTIONS = [
  { value: 'Datacenter', label: 'Datacenter' },
  { value: 'Operating System', label: 'Operating System' },
];

export function SidebarFilters({ filters, onFiltersChange }: SidebarFiltersProps) {
  const [expandedSections, setExpandedSections] = useState<Set<string>>(
    new Set(['status', 'type'])
  );

  const toggleSection = (section: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(section)) {
      newExpanded.delete(section);
    } else {
      newExpanded.add(section);
    }
    setExpandedSections(newExpanded);
  };

  const handleStatusChange = (value: string, checked: boolean) => {
    const newStatus = checked
      ? [...filters.status, value]
      : filters.status.filter(s => s !== value);
    onFiltersChange({ ...filters, status: newStatus });
  };

  const handleTypeChange = (value: string, checked: boolean) => {
    const newType = checked
      ? [...filters.migrationType, value]
      : filters.migrationType.filter(t => t !== value);
    onFiltersChange({ ...filters, migrationType: newType });
  };

  const handleSearchChange = (text: string) => {
    onFiltersChange({ ...filters, searchText: text });
  };

  const clearFilters = () => {
    onFiltersChange({
      dateRange: filters.dateRange,
      status: [],
      migrationType: [],
      searchText: '',
    });
  };

  return (
    <aside className="w-64 bg-secondary border-r border-border overflow-y-auto hidden lg:block">
      <div className="p-4 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-foreground flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filters
          </h2>
          {(filters.status.length > 0 || filters.migrationType.length > 0 || filters.searchText) && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="text-xs text-muted-foreground hover:text-foreground"
            >
              Clear
            </Button>
          )}
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-2 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search batch name..."
            value={filters.searchText}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="pl-8 bg-card border-border text-foreground placeholder:text-muted-foreground"
          />
        </div>

        {/* Status Filter */}
        <div className="space-y-2">
          <button
            onClick={() => toggleSection('status')}
            className="w-full flex items-center justify-between text-sm font-semibold text-foreground hover:text-primary transition-colors"
          >
            Status ({filters.status.length})
            <ChevronDown
              className={`w-4 h-4 transition-transform ${
                expandedSections.has('status') ? 'rotate-0' : '-rotate-90'
              }`}
            />
          </button>

          {expandedSections.has('status') && (
            <div className="space-y-2 pl-2">
              {STATUS_OPTIONS.map((option) => (
                <div key={option.value} className="flex items-center gap-2">
                  <Checkbox
                    id={`status-${option.value}`}
                    checked={filters.status.includes(option.value)}
                    onCheckedChange={(checked) =>
                      handleStatusChange(option.value, checked as boolean)
                    }
                    className="border-border"
                  />
                  <label
                    htmlFor={`status-${option.value}`}
                    className={`text-sm cursor-pointer ${option.color}`}
                  >
                    {option.label}
                  </label>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Migration Type Filter */}
        <div className="space-y-2">
          <button
            onClick={() => toggleSection('type')}
            className="w-full flex items-center justify-between text-sm font-semibold text-foreground hover:text-primary transition-colors"
          >
            Migration Type ({filters.migrationType.length})
            <ChevronDown
              className={`w-4 h-4 transition-transform ${
                expandedSections.has('type') ? 'rotate-0' : '-rotate-90'
              }`}
            />
          </button>

          {expandedSections.has('type') && (
            <div className="space-y-2 pl-2">
              {TYPE_OPTIONS.map((option) => (
                <div key={option.value} className="flex items-center gap-2">
                  <Checkbox
                    id={`type-${option.value}`}
                    checked={filters.migrationType.includes(option.value)}
                    onCheckedChange={(checked) =>
                      handleTypeChange(option.value, checked as boolean)
                    }
                    className="border-border"
                  />
                  <label
                    htmlFor={`type-${option.value}`}
                    className="text-sm cursor-pointer text-foreground"
                  >
                    {option.label}
                  </label>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}
