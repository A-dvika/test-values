'use client';

import React, { useState, useMemo } from 'react';
import { Header } from './Header';
import { GovernancePanel } from './GovernancePanel';
import { SidebarFilters } from './SidebarFilters';
import { BatchList } from './BatchList';
import { ConfirmationPanel } from './ConfirmationPanel';
import { ExportDialog } from './ExportDialog';
import { mockMigrations } from './mockData';

export type Migration = {
  id: string;
  targetMigrationDate: string;
  customBatchName: string;
  status: 'Queued' | 'Approved' | 'In Progress' | 'Completed' | 'Failed' | 'Unapproved';
  migrationStatus: string;
  migrationType: string;
  submittedBy: string;
  user: string;
};

export type FilterState = {
  dateRange: [string, string];
  status: string[];
  migrationType: string[];
  searchText: string;
};

export default function MigrationTracker() {
  const [migrations, setMigrations] = useState<Migration[]>(mockMigrations);
  const [selectedMigrations, setSelectedMigrations] = useState<Set<string>>(new Set());
  const [filters, setFilters] = useState<FilterState>({
    dateRange: ['2026-02-07', '2026-02-28'],
    status: [],
    migrationType: [],
    searchText: '',
  });
  const [expandedBatches, setExpandedBatches] = useState<Set<string>>(new Set());
  const [confirmAction, setConfirmAction] = useState<{
    type: 'approve' | 'retry' | 'cancel' | 'reschedule' | null;
    migrations: string[];
  }>({ type: null, migrations: [] });
  const [isExporting, setIsExporting] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);

  // Compute statistics
  const stats = useMemo(() => {
    const total = migrations.length;
    const awaitingApproval = migrations.filter(m => m.status === 'Unapproved').length;
    const inProgress = migrations.filter(m => m.status === 'In Progress').length;
    const failed = migrations.filter(m => m.status === 'Failed').length;
    const completed = migrations.filter(m => m.status === 'Completed').length;
    const cancelled = migrations.filter(m => m.status === 'Queued' && m.migrationStatus === 'Cancelled').length;

    return { total, awaitingApproval, inProgress, failed, completed, cancelled };
  }, [migrations]);

  // Apply filters
  const filteredMigrations = useMemo(() => {
    return migrations.filter(m => {
      const dateOk = m.targetMigrationDate >= filters.dateRange[0] && m.targetMigrationDate <= filters.dateRange[1];
      const statusOk = filters.status.length === 0 || filters.status.includes(m.status);
      const typeOk = filters.migrationType.length === 0 || filters.migrationType.includes(m.migrationType);
      const searchOk = m.customBatchName.toLowerCase().includes(filters.searchText.toLowerCase()) ||
                       m.submittedBy.toLowerCase().includes(filters.searchText.toLowerCase());

      return dateOk && statusOk && typeOk && searchOk;
    });
  }, [migrations, filters]);

  // Group migrations by batch
  const batches = useMemo(() => {
    const grouped = new Map<string, Migration[]>();
    
    filteredMigrations.forEach(m => {
      const key = `${m.targetMigrationDate}-${m.customBatchName}`;
      if (!grouped.has(key)) {
        grouped.set(key, []);
      }
      grouped.get(key)!.push(m);
    });

    return Array.from(grouped.entries()).map(([key, migrations]) => {
      const [date, batchName] = key.split('-');
      const failed = migrations.filter(m => m.status === 'Failed').length;
      const unapproved = migrations.filter(m => m.status === 'Unapproved').length;
      const inProgress = migrations.filter(m => m.status === 'In Progress').length;

      return {
        id: key,
        date,
        batchName,
        migrations,
        stats: { total: migrations.length, failed, unapproved, inProgress },
        riskLevel: failed > 0 ? 'high' : unapproved > 0 ? 'medium' : 'low',
      };
    }).sort((a, b) => {
      // Risk-first sorting: Failed, Unapproved, In Progress, Scheduled, Completed
      const riskOrder = { high: 0, medium: 1, low: 2 };
      if (riskOrder[a.riskLevel as keyof typeof riskOrder] !== riskOrder[b.riskLevel as keyof typeof riskOrder]) {
        return riskOrder[a.riskLevel as keyof typeof riskOrder] - riskOrder[b.riskLevel as keyof typeof riskOrder];
      }
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    });
  }, [filteredMigrations]);

  const handleBatchToggle = (batchId: string) => {
    const newExpanded = new Set(expandedBatches);
    if (newExpanded.has(batchId)) {
      newExpanded.delete(batchId);
    } else {
      newExpanded.add(batchId);
    }
    setExpandedBatches(newExpanded);
  };

  const handleSelectMigration = (id: string, selected: boolean) => {
    const newSelected = new Set(selectedMigrations);
    if (selected) {
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    setSelectedMigrations(newSelected);
  };

  const handleAction = (action: 'approve' | 'retry' | 'cancel' | 'reschedule', migrationIds: string[]) => {
    setConfirmAction({ type: action, migrations: migrationIds });
  };

  const handleConfirmAction = (rescheduleDate?: string) => {
    if (!confirmAction.type) return;

    const updatedMigrations = migrations.map(m => {
      if (!confirmAction.migrations.includes(m.id)) return m;

      switch (confirmAction.type) {
        case 'approve':
          return { ...m, status: 'Approved' as const };
        case 'retry':
          return { ...m, status: 'Queued' as const, migrationStatus: 'Queued' };
        case 'cancel':
          return { ...m, status: 'Queued' as const, migrationStatus: 'Cancelled' };
        case 'reschedule':
          return { ...m, targetMigrationDate: rescheduleDate || m.targetMigrationDate };
        default:
          return m;
      }
    });

    setMigrations(updatedMigrations);
    setSelectedMigrations(new Set());
    setConfirmAction({ type: null, migrations: [] });
  };

  const handleExport = (type: 'all' | 'selected' | 'failed') => {
    let dataToExport = migrations;

    if (type === 'selected') {
      dataToExport = migrations.filter(m => selectedMigrations.has(m.id));
    } else if (type === 'failed') {
      dataToExport = migrations.filter(m => m.status === 'Failed');
    }

    const csv = [
      ['Date', 'Batch Name', 'Status', 'Migration Status', 'Type', 'Submitted By', 'User'],
      ...dataToExport.map(m => [
        m.targetMigrationDate,
        m.customBatchName,
        m.status,
        m.migrationStatus,
        m.migrationType,
        m.submittedBy,
        m.user,
      ]),
    ].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `migrations-${type}-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);

    setIsExporting(false);
  };

  return (
    <div className="flex h-screen bg-background text-foreground">
      {/* Sidebar */}
      <SidebarFilters filters={filters} onFiltersChange={setFilters} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <Header
          dateRange={filters.dateRange}
          onDateRangeChange={(range) => setFilters({ ...filters, dateRange: range })}
          autoRefresh={autoRefresh}
          onAutoRefreshChange={setAutoRefresh}
          selectedCount={selectedMigrations.size}
          onExport={() => setIsExporting(true)}
          onApprove={() => handleAction('approve', Array.from(selectedMigrations))}
          onRetry={() => handleAction('retry', Array.from(selectedMigrations))}
          onCancel={() => handleAction('cancel', Array.from(selectedMigrations))}
          onReschedule={() => handleAction('reschedule', Array.from(selectedMigrations))}
          hasSelected={selectedMigrations.size > 0}
        />

        {/* Content Area */}
        <div className="flex-1 overflow-auto">
          <div className="p-6 space-y-6">
            {/* Governance Panel */}
            <GovernancePanel
              stats={stats}
              onStatClick={(stat) => {
                if (stat === 'awaitingApproval') {
                  setFilters({ ...filters, status: ['Unapproved'] });
                } else if (stat === 'failed') {
                  setFilters({ ...filters, status: ['Failed'] });
                }
              }}
            />

            {/* Batch List */}
            <BatchList
              batches={batches}
              expandedBatches={expandedBatches}
              selectedMigrations={selectedMigrations}
              onBatchToggle={handleBatchToggle}
              onSelectMigration={handleSelectMigration}
              onAction={handleAction}
            />
          </div>
        </div>
      </div>

      {/* Confirmation Panel */}
      {confirmAction.type && (
        <ConfirmationPanel
          action={confirmAction.type}
          count={confirmAction.migrations.length}
          onConfirm={handleConfirmAction}
          onCancel={() => setConfirmAction({ type: null, migrations: [] })}
        />
      )}

      {/* Export Dialog */}
      {isExporting && (
        <ExportDialog
          onExport={handleExport}
          onClose={() => setIsExporting(false)}
          hasSelected={selectedMigrations.size > 0}
        />
      )}
    </div>
  );
}
