'use client';

import React from 'react';
import { Card } from '@/components/ui/card';
import { AlertCircle, CheckCircle2, Clock, Zap, XCircle, Pause } from 'lucide-react';

interface Stats {
  total: number;
  awaitingApproval: number;
  inProgress: number;
  failed: number;
  completed: number;
  cancelled: number;
}

interface GovernancePanelProps {
  stats: Stats;
  onStatClick: (stat: keyof Stats | string) => void;
}

export function GovernancePanel({ stats, onStatClick }: GovernancePanelProps) {
  const metrics = [
    {
      key: 'total',
      label: 'Total Migrations',
      value: stats.total,
      icon: Zap,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
      onClick: null,
    },
    {
      key: 'awaitingApproval',
      label: 'Awaiting Approval',
      value: stats.awaitingApproval,
      icon: Clock,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-400/10',
      onClick: () => onStatClick('awaitingApproval'),
    },
    {
      key: 'inProgress',
      label: 'In Progress',
      value: stats.inProgress,
      icon: AlertCircle,
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
      onClick: null,
    },
    {
      key: 'failed',
      label: 'Failed',
      value: stats.failed,
      icon: XCircle,
      color: 'text-red-400',
      bgColor: 'bg-red-400/10',
      onClick: () => onStatClick('failed'),
    },
    {
      key: 'completed',
      label: 'Completed',
      value: stats.completed,
      icon: CheckCircle2,
      color: 'text-green-400',
      bgColor: 'bg-green-400/10',
      onClick: null,
    },
    {
      key: 'cancelled',
      label: 'Cancelled',
      value: stats.cancelled,
      icon: Pause,
      color: 'text-gray-400',
      bgColor: 'bg-gray-400/10',
      onClick: null,
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      {metrics.map((metric) => {
        const Icon = metric.icon;
        const isClickable = metric.onClick !== null;

        return (
          <Card
            key={metric.key}
            className={`p-4 border border-border bg-card transition-all ${
              isClickable ? 'cursor-pointer hover:bg-secondary hover:border-primary' : ''
            }`}
            onClick={metric.onClick}
          >
            <div className="flex items-center gap-3">
              <div className={`${metric.bgColor} p-3 rounded-lg`}>
                <Icon className={`w-5 h-5 ${metric.color}`} />
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground font-medium">{metric.label}</p>
                <p className={`text-2xl font-bold ${metric.color}`}>{metric.value}</p>
              </div>
            </div>
            {isClickable && (
              <p className="text-xs text-muted-foreground mt-2">Click to filter</p>
            )}
          </Card>
        );
      })}
    </div>
  );
}
