'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { RefreshCw, Download, CheckCircle2, RotateCcw, X, Clock } from 'lucide-react';

interface HeaderProps {
  dateRange: [string, string];
  onDateRangeChange: (range: [string, string]) => void;
  autoRefresh: boolean;
  onAutoRefreshChange: (enabled: boolean) => void;
  selectedCount: number;
  onExport: () => void;
  onApprove: () => void;
  onRetry: () => void;
  onCancel: () => void;
  onReschedule: () => void;
  hasSelected: boolean;
}

export function Header({
  dateRange,
  onDateRangeChange,
  autoRefresh,
  onAutoRefreshChange,
  selectedCount,
  onExport,
  onApprove,
  onRetry,
  onCancel,
  onReschedule,
  hasSelected,
}: HeaderProps) {
  const [showDatePicker, setShowDatePicker] = useState(false);

  return (
    <header className="border-b border-border bg-card">
      <div className="flex items-center justify-between p-4 gap-4">
        {/* Left Section: Title and Date */}
        <div className="flex items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Migration Status</h1>
            <p className="text-sm text-muted-foreground">
              {dateRange[0]} to {dateRange[1]}
            </p>
          </div>
        </div>

        {/* Middle Section: Date Range Picker */}
        <div className="hidden lg:flex items-center gap-2 px-4 py-2 bg-secondary rounded-md border border-border">
          <input
            type="date"
            value={dateRange[0]}
            onChange={(e) => onDateRangeChange([e.target.value, dateRange[1]])}
            className="bg-transparent text-sm text-foreground outline-none"
          />
          <span className="text-muted-foreground">→</span>
          <input
            type="date"
            value={dateRange[1]}
            onChange={(e) => onDateRangeChange([dateRange[0], e.target.value])}
            className="bg-transparent text-sm text-foreground outline-none"
          />
        </div>

        {/* Right Section: Controls */}
        <div className="flex items-center gap-2">
          {/* Refresh Button */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.location.reload()}
            className="gap-1"
          >
            <RefreshCw className="w-4 h-4" />
            <span className="hidden sm:inline">Refresh</span>
          </Button>

          {/* Auto-Refresh Toggle */}
          <Button
            variant={autoRefresh ? 'default' : 'outline'}
            size="sm"
            onClick={() => onAutoRefreshChange(!autoRefresh)}
            className="gap-1"
          >
            <Clock className="w-4 h-4" />
            <span className="hidden sm:inline">Auto</span>
          </Button>

          {/* Selection Stats */}
          {hasSelected && (
            <div className="px-3 py-2 rounded-md bg-secondary text-sm text-muted-foreground">
              {selectedCount} selected
            </div>
          )}

          {/* Bulk Actions */}
          {hasSelected && (
            <div className="flex items-center gap-1 ml-2 pl-2 border-l border-border">
              <Button
                variant="outline"
                size="sm"
                onClick={onApprove}
                className="gap-1 text-green-400 border-green-400/50 hover:bg-green-400/10"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span className="hidden sm:inline">Approve</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onRetry}
                className="gap-1 text-yellow-400 border-yellow-400/50 hover:bg-yellow-400/10"
              >
                <RotateCcw className="w-4 h-4" />
                <span className="hidden sm:inline">Retry</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onCancel}
                className="gap-1 text-red-400 border-red-400/50 hover:bg-red-400/10"
              >
                <X className="w-4 h-4" />
                <span className="hidden sm:inline">Cancel</span>
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    More
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={onReschedule}>
                    Reschedule
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={onExport}>
                    Export Selected
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          )}

          {/* Export Button */}
          <Button
            variant="outline"
            size="sm"
            onClick={onExport}
            className="gap-1"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Export</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
