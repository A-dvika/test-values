'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { AlertCircle } from 'lucide-react';

interface ConfirmationPanelProps {
  action: 'approve' | 'retry' | 'cancel' | 'reschedule';
  count: number;
  onConfirm: (rescheduleDate?: string) => void;
  onCancel: () => void;
}

export function ConfirmationPanel({
  action,
  count,
  onConfirm,
  onCancel,
}: ConfirmationPanelProps) {
  const [rescheduleDate, setRescheduleDate] = useState('');
  const [confirmText, setConfirmText] = useState('');

  const requiresTextConfirm = count > 500;
  const confirmationThreshold = action === 'cancel' ? 'CANCEL' : action.toUpperCase();

  const getActionConfig = (act: typeof action) => {
    switch (act) {
      case 'approve':
        return {
          title: 'Approve Migrations',
          description: `You are about to approve ${count} migration(s). This action is irreversible.`,
          confirmLabel: 'Approve All',
          color: 'text-green-400',
          bgColor: 'bg-green-400/10',
          borderColor: 'border-green-400/30',
          buttonColor: 'bg-green-400 hover:bg-green-400/80',
        };
      case 'retry':
        return {
          title: 'Retry Failed Migrations',
          description: `You are about to retry ${count} failed migration(s).`,
          confirmLabel: 'Retry All',
          color: 'text-yellow-400',
          bgColor: 'bg-yellow-400/10',
          borderColor: 'border-yellow-400/30',
          buttonColor: 'bg-yellow-400 hover:bg-yellow-400/80',
        };
      case 'cancel':
        return {
          title: 'Cancel Migrations',
          description: `You are about to cancel ${count} migration(s). This cannot be undone.`,
          confirmLabel: 'Cancel All',
          color: 'text-red-400',
          bgColor: 'bg-red-400/10',
          borderColor: 'border-red-400/30',
          buttonColor: 'bg-red-400 hover:bg-red-400/80',
        };
      case 'reschedule':
        return {
          title: 'Reschedule Migrations',
          description: `You are about to reschedule ${count} migration(s).`,
          confirmLabel: 'Reschedule All',
          color: 'text-blue-400',
          bgColor: 'bg-blue-400/10',
          borderColor: 'border-blue-400/30',
          buttonColor: 'bg-blue-400 hover:bg-blue-400/80',
        };
    }
  };

  const config = getActionConfig(action);
  const isConfirmDisabled = action === 'reschedule' ? !rescheduleDate : requiresTextConfirm && confirmText !== confirmationThreshold;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div
        className={`${config.bgColor} border ${config.borderColor} rounded-lg p-6 max-w-sm w-full mx-4 shadow-2xl`}
      >
        {/* Header */}
        <div className="flex items-start gap-3 mb-4">
          <AlertCircle className={`w-6 h-6 ${config.color} flex-shrink-0 mt-1`} />
          <div>
            <h2 className="text-lg font-bold text-foreground">{config.title}</h2>
            <p className="text-sm text-muted-foreground mt-1">{config.description}</p>
          </div>
        </div>

        {/* Reschedule Date Input */}
        {action === 'reschedule' && (
          <div className="mb-4">
            <label className="block text-sm font-medium text-foreground mb-2">
              New Migration Date
            </label>
            <Input
              type="date"
              value={rescheduleDate}
              onChange={(e) => setRescheduleDate(e.target.value)}
              className="bg-card border-border text-foreground"
              min={new Date().toISOString().split('T')[0]}
            />
          </div>
        )}

        {/* Confirmation Text Input */}
        {requiresTextConfirm && (
          <div className="mb-4">
            <label className="block text-sm font-medium text-foreground mb-2">
              Type <span className={config.color}>{confirmationThreshold}</span> to confirm
            </label>
            <Input
              type="text"
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value.toUpperCase())}
              placeholder={confirmationThreshold}
              className="bg-card border-border text-foreground uppercase"
            />
            <p className="text-xs text-muted-foreground mt-1">
              ({count} migrations is a large batch, please confirm)
            </p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={onCancel}
            className="flex-1 border-border text-foreground hover:bg-secondary"
          >
            Cancel
          </Button>
          <Button
            onClick={() => onConfirm(action === 'reschedule' ? rescheduleDate : undefined)}
            disabled={isConfirmDisabled}
            className={`flex-1 text-black font-semibold ${config.buttonColor} disabled:opacity-50`}
          >
            {config.confirmLabel}
          </Button>
        </div>
      </div>
    </div>
  );
}
